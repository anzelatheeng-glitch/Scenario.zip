public class CollegePayroll{
    public static void main(String[] args){
        
        Teacher t1 = new Teacher (1, "Arya Pokhrel", 45000.00, "Programming", 2000.00);
        Teacher t2 = new Teacher (2, "Subash Sharma", 40000.00, "Computer Hardware", 1500.00);
        
        Staff s1 = new Staff (3, "Sandesh Tamrakar", 20000.00, 170, 200.00);
        Staff s2 = new Staff (4, "Sadaf Akhtar", 25000.00, 150, 250.00);
        
        System.out.println("======== College Payroll System ========");
        System.out.println("College : "+Person.collegeName);
        System.out.println("========================================");
        
        t1.displayDetails();
        t2.displayDetails();
        
        s1.displayDetails();
        s2.displayDetails();
        
        System.out.println("\n======== Salary Summary ========");
        System.out.println(t1.name+"(Teacher) Annual Salary : Rs. "+t1.calculateAnnualSalary());
        System.out.println(t2.name+"(Teacher) Annual Salary : Rs. "+t2.calculateAnnualSalary());
        System.out.println(s1.name+"(Staff) Monthly Salary : Rs. "+s1.calculateSalary());
        System.out.println(s2.name+"(Staff) Monthly Salary : Rs. "+s2.calculateSalary());
        System.out.println("==================================");
        System.out.println("College : "+Person.collegeName);
        System.out.println("==================================");
    }
}