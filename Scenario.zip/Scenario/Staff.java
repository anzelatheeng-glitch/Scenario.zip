class Staff extends Person{
    int workingHours;
    double ratePerHour;
    public Staff(int id, String name, double basicSalary,int workingHours,double ratePerHour){
        super(id,name,basicSalary);
        this.workingHours = workingHours;
        this.ratePerHour = ratePerHour;
    }
    
    double calculateSalary(){
        return workingHours * ratePerHour;
    }
    
    void displayDetails(){
        System.out.println("\n========== Staff Details ==========");
        System.out.println("ID : "+ id);
        System.out.println("Staff's Name : "+ name);
        System.out.println("Working Hours : "+ workingHours);
        System.out.println("Rate Per Hour : Rs. "+ ratePerHour);
        System.out.println("Calculated Salary : Rs. "+calculateAnnualSalary());
        System.out.println("===================================");
    }
}      