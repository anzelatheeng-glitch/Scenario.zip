class Teacher extends Person{
    String subject;
    double bonus;
    public Teacher (int id, String name, double basicSalary, String subject, double bonus){
        super(id, name, basicSalary);
        this.subject = subject;
        this.bonus = bonus;
    }
    
    @Override
    double calculateAnnualSalary(){
        return super.calculateAnnualSalary() + bonus;  
    }
    
    void displayDetails(){
        System.out.println("\n========== Teacher Details ==========");
        System.out.println("ID : "+ id);
        System.out.println("Teacher's Name : "+ name);
        System.out.println("Subject : "+ subject);
        System.out.println("Basic Salary : Rs. "+ basicSalary);
        System.out.println("Bonus : Rs. "+ bonus);
        System.out.println("Annual Salary : Rs. "+calculateAnnualSalary() );
        System.out.println("=====================================");
    }
}