class Patient{
    String patientName;
    int age;
    int daysAdmitted;
    double dailyCharge;
    
    public Patient(String patientName, int age, int daysAdmitted, double dailyCharge){
        this.patientName = patientName;
        this.age = age;
        this.daysAdmitted = daysAdmitted;
        this.dailyCharge = dailyCharge;
    }
    
    double calculateTotalBill(){
        double totalBill = daysAdmitted * dailyCharge;
        if(daysAdmitted > 7){
            totalBill  = totalBill - (totalBill*0.10);
        }
        return totalBill;
    }
    
    void displayDetails(){
        System.out.println("\n------ Patient Details ------");
        System.out.println("Patient Name : "+ patientName);
        System.out.println("Age : "+ age);
        System.out.println("Days Admitted : "+ daysAdmitted+" days.");
        System.out.println("Daily Charge : "+ dailyCharge);
        if(daysAdmitted >7){
            System.out.println("Discount Applied : 10% (Longterm Stay Discount)");
        }else{
            System.out.println("Discount Applied : None");
        }
        System.out.println("Total Bill : "+ calculateTotalBill());
        System.out.println("---------------------------");
    }
}

public class HospitalTest{
    public static void main(String[] args){
        Patient p1 = new Patient ("Lata Kc", 70, 10, 2000.00);
        Patient p2 = new Patient ("Nirmala Shrestha", 67, 3, 1500.00);
        Patient p3 = new Patient ("Saroj Shakya", 55, 7, 3000.00);
        
        System.out.println("=============================");
        System.out.println("Hospital Billing System");
        System.out.println("=============================");
        p1.displayDetails();
        p2.displayDetails();
        p3.displayDetails();
        
        System.out.println("\n-----------------------------");
        System.out.println("BillSummary");
        System.out.println("-----------------------------");
        System.out.println(p1.patientName+" : "+ "Rs. "+p1.calculateTotalBill());
        System.out.println(p2.patientName+" : "+ "Rs. "+p2.calculateTotalBill());
        System.out.println(p3.patientName+" : "+ "Rs. "+p3.calculateTotalBill());
    }
}